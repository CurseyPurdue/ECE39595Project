#ifndef TWOTUPLE_H__
#define TWOTUPLE_H__

class TwoTuple{
    public:
        TwoTuple(int _location, int _size);
        int location;
        int size;
};

#endif