#include <iostream>
#include "TwoTuple.h"

TwoTuple::TwoTuple(int _location, int _size) : location(_location), size(_size) {}
